<!doctype html>
<?php require_once('./conn/conn.php');
session_start();
@$username=$_SESSION['user'];
@$vip=$_SESSION['vip'];
if($username=="" || empty($username)){
	header("Location: ./login.php");
	return 0;
}
?>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>一奇匿名聊天，这是一款基于nodejs和socket的聊天室，无需刷新页面，即时获取消息</title>
		<link href="./style/reset.css" rel="stylesheet" />
	  	<link href="./style/main.css" rel="stylesheet" />
		<link href="./style/yiqi.css" rel="stylesheet" />
</head>
<script type="text/JavaScript" src="./js/yiqi.js"></script>
<style>
	body { 
	position:relative;
	top:0;
	bottom:0;
    overflow-y:hidden; 
	}
</style>
<body bgcolor="#F5F5F5">
	<div id="box">
				<div class="bottom">
			<div id="left">
				<div class="touxiang" align="center">
					<img src="http://q2.qlogo.cn/headimg_dl?dst_uin=330729121&spec=4"  id="touxiang">
					<p>欢迎你游客</p>
				</div>
				<div align="left" class="cebianlan">
					<ul>
						<li  onClick="iFrame('./index.php')"><img src="./images/icon/zy.png"><a href="#">首页</a></li>
						<!--
						<li onClick="Newopen('http://www.q05.cc/chat/')"><img src="./images/icon/chat.png"><a href="#">匿名聊天</a></li>
						<li onClick="Newopen('http://www.q05.cc/yuanfen/admin')"><img src="./images/icon/yuanfen.png"><a href="#">查看对方喜欢谁</a></li>
						<li onClick="Newopen('http://www.q05.cc/love')"><img src="./images/icon/love2.png"><a href="#">表白</a></li>
						<li onClick="Newopen('http://www.q05.cc/ip')"><img src="./images/icon/ip1.png"><a href="#">ip定位</a></li>
						<li onClick="Newopen('http://www.q05.cc/')"><img src="./images/icon/book.png"><a href="#">一奇博客</a></li>
						<li  onClick="iFrame('http://www.q05.cc/jieshao.php')"><img src="./images/icon/touxiang.png"><a href="#">个人介绍</a></li>
						-->
					</ul>
				</div>
			</div>
			<div id="right">
					<iframe src='./chat.php' width='100%' height='100%' frameborder='0' name="_blank" id="iFrame-content" ></iframe>
					
			</div>
		</div>
		<div class="head">
			<h1>一奇聊天室</h1>
			<div class="openclose" id="openclose">
				<img id="xiangleftright" src="./images/icon/caidan2.png">
			</div>
			<div class="head-right" align="center">
			<?php
				session_start();
				@$username=$_SESSION['user'];
				if($username!=""){
					echo '<p onClick=\"\">'.$username.'</p>';
				}else{
					echo '<p onClick=\"\">登录</p>';
				}
			
			
			?>
				
			
				
				<img src="./images/icon/xia.png" onclick="xialadj()">
			</div>
			<div id="head-right-xiala" align="left" style="display: none;">
				
				<ul>
				<li onclick="exit()">退出登录</li>
					
					
					
					
				</ul>
				
			</div>
		</div>

		</div>
		
</body>

	<script type="text/JavaScript" src="./js/main.js"></script>
	<script type="text/JavaScript">
			var xialaheight = 0;
				xialadianji = byId("head-right-xiala");
				function xialadj(){
					if(xialadianji.style.display=="none"){
					   			xialadianji.style.display="block";
								xialaheight=byId("head-right-xiala").scrollHeight,
								xialadianji.style.height=0+"px";
								xialadianji.style.height=xialaheight+"px";
					   }else if(xialadianji.style.height=="0px"){
								xialadianji.style.height=xialaheight+"px";
						}else{
								xialaheight=byId("head-right-xiala").scrollHeight,
								xialadianji.style.height=0+"px";
					   }
					
				}
			function exit(){
				window.location.href="./zx.php";
			}

	</script>
</html>